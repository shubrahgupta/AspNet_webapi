﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Consume.Models;


namespace Consume.Controllers
{
    public class HomeController : Controller
    {
        public async Task<ActionResult> Index()
        {
            List<Product> products = new List<Product>();

            using (HttpClient client = new HttpClient())
            {
                var byteArray = Encoding.ASCII.GetBytes("admin:admin");
                client.DefaultRequestHeaders.Authorization
                          = new AuthenticationHeaderValue("Yo", Convert.ToBase64String(byteArray));
                client.BaseAddress = new Uri("https://localhost:44331/");
                HttpResponseMessage response = await client.GetAsync("api/product/");
                if (response.IsSuccessStatusCode)
                {
                    products = await response.Content.ReadAsAsync<List<Product>>();
                }
            }

            return View(products);
        }
    }


}
