﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;
using System.Net;
using System.Net.Http;
using System.Web.Http.Cors;
using Yoyo.Models;
using System.Threading;
using System.Runtime.Remoting.Messaging;
using System.Web.Http.ModelBinding;

namespace Yoyo.Controllers
{
    [YoAuthentication]
    public class ProductController : ApiController
    {

        public HttpResponseMessage GetProductById(int id)
        {

            var prod = new ProductList().GetProductById(id);
            if (prod != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK,
    prod);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }


        }
        public HttpResponseMessage GetProducts()
        {
 
            var prod = new ProductList().GetProducts();

            return Request.CreateResponse(HttpStatusCode.OK,
                prod);

        }

        [HttpPost]
        public HttpResponseMessage PostProduct([FromBody] Product product)
        {
            try
            {

                int id = new ProductList().CreateProducts(product);
                product.Id = id;
                var message = Request.CreateResponse(HttpStatusCode.Created, product);
                message.Headers.Location = new Uri(Request.RequestUri + "/" + id.ToString());
                return message;
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }




        }
        [HttpPut]
        public HttpResponseMessage UpdateProduct([FromBody] Product product)
        {

            new ProductList().EditDataInDatabase(product);

            return Request.CreateResponse(HttpStatusCode.Accepted);

        }

        public HttpResponseMessage DeleteProduct(int id)
        {

            new ProductList().DeleteFromDatabase(id);

            return Request.CreateResponse(HttpStatusCode.Accepted);

        }
    }

    //private string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";

    //[HttpGet]
    //public IHttpActionResult GetProducts()
    //{
    //    List<Product> products = new List<Product>();
    //    using (SqlConnection connection = new SqlConnection(connectionString))
    //    {
    //        connection.Open();
    //        SqlCommand command = new SqlCommand("SELECT Id, Name, Price FROM Products", connection);
    //        using (SqlDataReader reader = command.ExecuteReader())
    //        {
    //            while (reader.Read())
    //            {
    //                products.Add(new Product
    //                {
    //                    Id = Convert.ToInt32(reader["Id"]),
    //                    Name = reader["Name"].ToString(),
    //                    Price = Convert.ToDecimal(reader["Price"])
    //                });
    //            }
    //        }
    //    }
    //    return Ok(products);
    //}

    //[HttpGet]
    //public IHttpActionResult GetProduct(int id)
    //{
    //    // Implement fetching a specific product by ID
    //}

    //[HttpPut]
    //public IHttpActionResult UpdateProduct(int id, Product product)
    //{
    //    // Implement updating a product
    //}

    //[HttpDelete]
    //public IHttpActionResult DeleteProduct(int id)
    //{
    //    // Implement deleting a product
    //}


}



