﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Yoyo.Models
{
    public class UserValidate
    {
        public static bool Login(string username, string password)
        {
            UserList users = new UserList();
            var UserLists = users.GetUsers();
            return UserLists.Any(user =>
                user.UserName.Equals(username)
                && user.Password == password);
        }
    }
}