﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Yoyo.Models
{
    public class UserList
    {
        public List<User> GetUsers()
        {
            List<User> users = new List<User>();
            //string strcon = WebConfigurationManager.ConnectionStrings["productDBconnection"].ConnectionString;
            string strcon = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT Id, UserName, Password FROM Users", connection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(new User
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            UserName = reader["UserName"].ToString(),
                            Password = reader["Password"].ToString()
                        });
                    }
                }
            }
            return users;
        }
    }
}