﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Yoyo.Models
{
    public class ProductList
    {
        public List<Product> GetProducts()
        {
            List<Product> products = new List<Product>();
            //string strcon = WebConfigurationManager.ConnectionStrings["productDBconnection"].ConnectionString;

            string strcon = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT Id, Name, Price FROM dbo.Product", connection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new Product
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Name = reader["Name"].ToString(),
                            Price = Convert.ToDecimal(reader["Price"])
                        });
                    }
                }
            }
            return products;
        }
        public Product GetProductById(int id)
        {

            //string strcon = WebConfigurationManager.ConnectionStrings["productDBconnection"].ConnectionString;

            string strcon = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT * FROM dbo.Product where Id=@Id", connection);
                command.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    
                    if (reader.HasRows)
                    {


                        while (reader.Read())
                        {
                            
                            string Name = reader.GetString(1);
                            decimal Price = reader.GetDecimal(2);
                            
                            return new Product { Id = id, Name = Name, Price = Price };

                        }

                    }
                }
            }
            return null;
        }


        public int CreateProducts(Product product)
        {

            //string strcon = WebConfigurationManager.ConnectionStrings["productDBconnection"].ConnectionString;

            string strcon = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";
            int id;
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();
                string query = "INSERT INTO [dbo].[Product]\r\n           ([Name]\r\n           ,[Price])\r\n     VALUES\r\n           (@Name\r\n           ,@Price) SELECT SCOPE_IDENTITY()";
                using (SqlCommand command = new SqlCommand(query, connection))
                {



                    command.Parameters.AddWithValue("@Name", product.Name);
                    command.Parameters.AddWithValue("@Price", product.Price);



                    id = Convert.ToInt32(command.ExecuteScalar());

                    
                }
                connection.Close();
                
            }
            return id;

        }

        public void DeleteFromDatabase(int id)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "DELETE FROM dbo.Product WHERE Id = @Id;";


                using (SqlCommand command = new SqlCommand(query, connection))
                {



                    command.Parameters.AddWithValue("@Id", id);



                    command.ExecuteNonQuery();
                }
            }
        }


        public void EditDataInDatabase(Product product)
        {

            string connectionString = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string query = "UPDATE [dbo].[Product]\r\n   SET [Name] = @Name\r\n      ,[Price] = @Price\r\n WHERE Id=@Id";


                using (SqlCommand command = new SqlCommand(query, connection))
                {


                    command.Parameters.AddWithValue("@Id", product.Id);
                    command.Parameters.AddWithValue("@Name", product.Name);
                    command.Parameters.AddWithValue("@Price", product.Price);


                    command.ExecuteNonQuery();
                }
            }
        }

        //private int FetchProductIdFromData(string Name, int Price)
        //{
        //    string strcon = "server = (LocalDb)\\MSSQLLocalDB; database = ProductDB; integrated security = SSPI";
        //    int id;
        //    using (SqlConnection connection = new SqlConnection(strcon))
        //    {
        //        connection.Open();
        //        string query = "SELECT * FROM [dbo].[Product] WHERE ([Name] = @Name ,[Price] = @Price)";
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {



        //            command.Parameters.AddWithValue("@Name", Name);
        //            command.Parameters.AddWithValue("@Price", Price);



        //            command.ExecuteNonQuery();

        //        }
        //        id =
        //    }


        //}
    }
}